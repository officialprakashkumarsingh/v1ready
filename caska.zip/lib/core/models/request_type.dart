enum RequestType { text, image, presentation, diagram }
